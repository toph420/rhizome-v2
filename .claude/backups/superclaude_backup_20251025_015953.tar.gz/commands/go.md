Always use:
- serena for semantic code retrieval and editing tools
- context7 for up to date documentation on third party code
- sequential thinking for any decision making
Read the claude.md root file before you do anything.
#$ARGUMENTS